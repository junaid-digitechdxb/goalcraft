import { Link } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, BarChart3, Users, Settings, Globe, CheckCircle2 } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ChatWidget } from "@/components/shared/ChatWidget";

// Images from unsplash using placeholder URLs as per instructions (tool will handle but here is structure)
// Using described aesthetic for "Abstract corporate"
const IMAGES = {
  hero: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop",
  operational: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=2070&auto=format&fit=crop",
  digital: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop",
  leader: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?q=80&w=2032&auto=format&fit=crop"
};

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* --- HERO SECTION --- */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-gray-50">
        <div className="absolute inset-0 z-0 opacity-5 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        <div className="container-custom relative z-10">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-primary leading-tight mb-6"
            >
              Transforming Operations into <span className="text-secondary">Profitable</span>, Data-Driven Enterprises
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto"
            >
              Leveraging 50+ years of executive expertise to bridge the gap between traditional operational excellence and modern digital innovation.
            </motion.p>
          </div>

          {/* Split Cards */}
          <div className="grid md:grid-cols-2 gap-0 shadow-2xl rounded-2xl overflow-hidden max-w-6xl mx-auto">
            
            {/* Left: Operational */}
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative group h-[500px] overflow-hidden"
            >
              <div className="absolute inset-0 bg-primary/90 z-10 transition-colors group-hover:bg-primary/80"></div>
              {/* Image bg */}
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                style={{ backgroundImage: `url(${IMAGES.operational})` }}
              ></div>
              
              <div className="relative z-20 h-full flex flex-col justify-center p-12 text-white">
                <div className="mb-6 inline-block px-3 py-1 border border-white/30 rounded-full text-xs font-semibold tracking-wider uppercase">
                  Proven Stability
                </div>
                <h2 className="text-3xl font-serif font-bold mb-4">Operational Services</h2>
                <p className="text-gray-200 mb-8 max-w-sm">
                  Foundational excellence in facility management, staffing, and operations support to ensure your business runs seamlessly.
                </p>
                <Link href="/services">
                  <button className="flex items-center gap-2 font-semibold hover:gap-4 transition-all">
                    Explore Operational Services <ArrowRight className="w-4 h-4" />
                  </button>
                </Link>
              </div>
            </motion.div>

            {/* Right: Digital */}
            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative group h-[500px] overflow-hidden"
            >
              <div className="absolute inset-0 bg-secondary/90 z-10 transition-colors group-hover:bg-secondary/80"></div>
              {/* Image bg */}
              <div 
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                style={{ backgroundImage: `url(${IMAGES.digital})` }}
              ></div>
              
              <div className="relative z-20 h-full flex flex-col justify-center p-12 text-white">
                <div className="mb-6 inline-block px-3 py-1 border border-white/30 rounded-full text-xs font-semibold tracking-wider uppercase">
                  Future Growth
                </div>
                <h2 className="text-3xl font-serif font-bold mb-4">Digital Business Solutions</h2>
                <p className="text-blue-50 mb-8 max-w-sm">
                  Strategic digital transformation, Zoho ERP implementation, and process optimization to scale your impact.
                </p>
                <Link href="/solutions">
                  <button className="flex items-center gap-2 font-semibold hover:gap-4 transition-all">
                    Explore Digital Transformation <ArrowRight className="w-4 h-4" />
                  </button>
                </Link>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* --- WHY CHOOSE US --- */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="w-full md:w-1/2">
               {/* Abstract corporate office */}
              <img 
                src={IMAGES.leader} 
                alt="Executive Meeting" 
                className="rounded-lg shadow-2xl"
              />
            </div>
            <div className="w-full md:w-1/2">
              <h4 className="text-secondary font-semibold uppercase tracking-wider text-sm mb-2">Why Goalcraft</h4>
              <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-6">Experience That Translates to Value</h2>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                In a world of generic consultants, Goalcraft stands apart. We don't just advise; we execute. Our leadership brings over 50 years of combined C-suite experience in navigating complex operational challenges and leading successful digital turnarounds.
              </p>
              
              <div className="space-y-4">
                {[
                  "ROI-Driven Delivery Models",
                  "End-to-End Zoho ERP Expertise",
                  "Change Management that Sticks",
                  "Operations & Digital Under One Roof"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="w-5 h-5 text-secondary" />
                    <span className="font-medium text-primary">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- SERVICES PREVIEW --- */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-primary mb-4">Comprehensive Enterprise Solutions</h2>
            <p className="text-muted-foreground">From keeping the lights on to lighting the way forward.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { 
                icon: <Settings className="w-8 h-8 text-secondary" />, 
                title: "Operational Excellence", 
                desc: "Streamlining facility management and staffing to reduce overhead and improve reliability." 
              },
              { 
                icon: <Globe className="w-8 h-8 text-secondary" />, 
                title: "Digital Strategy", 
                desc: "Roadmapping your digital future with technology that serves your business goals, not the other way around." 
              },
              { 
                icon: <BarChart3 className="w-8 h-8 text-secondary" />, 
                title: "Data & Analytics", 
                desc: "Turning raw operational data into actionable executive insights for better decision making." 
              }
            ].map((card, i) => (
              <div key={i} className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
                <div className="mb-6 bg-blue-50 w-16 h-16 rounded-lg flex items-center justify-center">
                  {card.icon}
                </div>
                <h3 className="text-xl font-bold text-primary mb-3">{card.title}</h3>
                <p className="text-muted-foreground leading-relaxed text-sm">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- CTA SECTION --- */}
      <section className="py-24 bg-primary text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="container-custom relative z-10 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">Ready to Optimize Your Enterprise?</h2>
          <p className="text-blue-100 max-w-2xl mx-auto mb-10 text-lg">
            Schedule a complimentary discovery session with our executive team to identify your biggest opportunities for growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <button className="btn-secondary h-12 px-8 text-base">
                Request Consultation
              </button>
            </Link>
            <Link href="/about">
              <button className="h-12 px-8 rounded-md border border-white/20 hover:bg-white/10 transition-colors font-medium">
                Learn About Our Team
              </button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
      <ChatWidget />
    </div>
  );
}
