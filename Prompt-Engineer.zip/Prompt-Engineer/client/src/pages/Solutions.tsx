import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ChatWidget } from "@/components/shared/ChatWidget";
import { LayoutGrid, TrendingUp, RefreshCw, Layers } from "lucide-react";

export default function Solutions() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="bg-secondary text-white pt-32 pb-16">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Digital Business Solutions</h1>
          <p className="text-blue-50 max-w-2xl mx-auto text-lg">
            Future-proofing your business with integrated technology and data strategies.
          </p>
        </div>
      </div>

      {/* Intro */}
      <section className="py-20 bg-white">
        <div className="container-custom text-center max-w-4xl mx-auto">
          <h2 className="text-3xl font-serif font-bold text-primary mb-6">The Zoho ERP Hub</h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
             We specialize in the Zoho ecosystem because it offers the most cohesive suite of applications for modern enterprises. From CRM to Finance, Inventory to HR, we connect the dots so data flows freely across your organization.
          </p>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="pb-24 bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8">
            
            {/* Card 1 */}
            <div className="bg-gray-50 p-10 rounded-2xl border border-gray-100 hover:border-secondary/30 transition-all">
              <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center mb-6 text-secondary">
                <LayoutGrid className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">ERP Implementation</h3>
              <p className="text-muted-foreground mb-6">
                End-to-end setup of Zoho One. We handle data migration, configuration, and customization to match your unique business logic.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                 <li>• Custom Module Development</li>
                 <li>• Legacy Data Migration</li>
                 <li>• Role-Based Access Control</li>
              </ul>
            </div>

            {/* Card 2 */}
            <div className="bg-gray-50 p-10 rounded-2xl border border-gray-100 hover:border-secondary/30 transition-all">
              <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center mb-6 text-secondary">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Business Intelligence (BI)</h3>
              <p className="text-muted-foreground mb-6">
                Turn data into decisions with Zoho Analytics. We build executive dashboards that give you real-time visibility into KPIs.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                 <li>• Cross-Department Reporting</li>
                 <li>• Predictive Analytics</li>
                 <li>• Automated Email Reports</li>
              </ul>
            </div>

            {/* Card 3 */}
            <div className="bg-gray-50 p-10 rounded-2xl border border-gray-100 hover:border-secondary/30 transition-all">
              <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center mb-6 text-secondary">
                <RefreshCw className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Process Automation</h3>
              <p className="text-muted-foreground mb-6">
                Eliminate manual data entry. We design automated workflows (Blueprints) that ensure consistency and speed up cycle times.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                 <li>• Sales Funnel Automation</li>
                 <li>• Approval Workflows</li>
                 <li>• Customer Support Routing</li>
              </ul>
            </div>

             {/* Card 4 */}
             <div className="bg-gray-50 p-10 rounded-2xl border border-gray-100 hover:border-secondary/30 transition-all">
              <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center mb-6 text-secondary">
                <Layers className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">Change Management</h3>
              <p className="text-muted-foreground mb-6">
                Technology is only as good as adoption. We provide training and change management strategies to ensure your team embraces the new tools.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                 <li>• User Training Workshops</li>
                 <li>• Documentation & SOPs</li>
                 <li>• Post-Launch Support</li>
              </ul>
            </div>

          </div>
        </div>
      </section>

      <Footer />
      <ChatWidget />
    </div>
  );
}
