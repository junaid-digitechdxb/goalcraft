import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ChatWidget } from "@/components/shared/ChatWidget";
import { Hammer, Users, ClipboardCheck, ArrowRight } from "lucide-react";

export default function Services() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="bg-slate-900 text-white pt-32 pb-16">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Operational Services</h1>
          <p className="text-slate-300 max-w-2xl mx-auto text-lg">
            The backbone of your enterprise, managed with precision and expertise.
          </p>
        </div>
      </div>

      <section className="section-padding">
        <div className="container-custom">
          <div className="grid gap-12">
            
            {/* Service 1 */}
            <div className="flex flex-col md:flex-row gap-8 border-b border-gray-100 pb-12">
              <div className="md:w-1/3">
                <div className="bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <Hammer className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-primary">Facility Management</h3>
              </div>
              <div className="md:w-2/3">
                <p className="text-muted-foreground mb-6 text-lg">
                  Comprehensive oversight of your physical assets. We ensure your facilities are safe, compliant, and conducive to productivity. From preventative maintenance schedules to vendor management, we handle the details so you can focus on the core business.
                </p>
                <ul className="grid md:grid-cols-2 gap-3">
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Predictive Maintenance</li>
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Vendor Consolidation</li>
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Safety Compliance Audits</li>
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Space Utilization Optimization</li>
                </ul>
              </div>
            </div>

            {/* Service 2 */}
            <div className="flex flex-col md:flex-row gap-8 border-b border-gray-100 pb-12">
              <div className="md:w-1/3">
                <div className="bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <Users className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-primary">Staffing Solutions</h3>
              </div>
              <div className="md:w-2/3">
                <p className="text-muted-foreground mb-6 text-lg">
                  Providing the human capital necessary to scale. Whether you need temporary labor for peak seasons or specialized technical roles, our vetting process ensures you get reliable, skilled personnel.
                </p>
                <ul className="grid md:grid-cols-2 gap-3">
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Temporary & Contract Staffing</li>
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Direct Hire Recruitment</li>
                  <li className="flex items-center gap-2 text-sm font-medium"><div className="w-1.5 h-1.5 rounded-full bg-secondary"></div>Workforce Management</li>
                </ul>
              </div>
            </div>

            {/* Service 3 */}
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-1/3">
                <div className="bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                  <ClipboardCheck className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-2xl font-serif font-bold text-primary">Operations Support</h3>
              </div>
              <div className="md:w-2/3">
                <p className="text-muted-foreground mb-6 text-lg">
                  Process re-engineering and logistical support to remove bottlenecks. We analyze your workflows and implement standard operating procedures (SOPs) that drive consistency and quality.
                </p>
                <a href="/contact" className="text-secondary font-semibold inline-flex items-center gap-2 hover:gap-3 transition-all">
                  Discuss Your Operations <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>

      <Footer />
      <ChatWidget />
    </div>
  );
}
