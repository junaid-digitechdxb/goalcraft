import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ChatWidget } from "@/components/shared/ChatWidget";

const LEADERS = [
  {
    name: "James Sterling",
    role: "Chief Executive Officer",
    bio: "Former VP of Operations at Fortune 500 manufacturing firm. 25 years specializing in operational efficiency and turnarounds.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=2574&auto=format&fit=crop"
  },
  {
    name: "Elena Rodriguez",
    role: "Head of Digital Transformation",
    bio: "Tech strategist with a background in ERP implementation and systems architecture for global logistics companies.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=2576&auto=format&fit=crop"
  },
  {
    name: "Marcus Chen",
    role: "Director of Strategy",
    bio: "MBA from Wharton. Focuses on bridging the gap between C-suite strategy and ground-level execution.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=2070&auto=format&fit=crop"
  }
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Header */}
      <div className="bg-primary text-white pt-32 pb-16">
        <div className="container-custom text-center">
          <h1 className="text-4xl md:text-5xl font-serif font-bold mb-4">Our Story & Leadership</h1>
          <p className="text-blue-100 max-w-2xl mx-auto text-lg">
            Building on a legacy of trust to define the future of business operations.
          </p>
        </div>
      </div>

      {/* Story Section */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-serif font-bold text-primary mb-6">From Facility Management to Digital Innovation</h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Goalcraft began as a specialized facility management firm, dedicated to the hard work of keeping physical operations running smoothly. We understood that reliability was the currency of trust.
                </p>
                <p>
                  As our clients grew, so did their challenges. The physical world was colliding with the digital one. Our clients didn't just need clean floors and staffed warehouses; they needed data visibility, automated workflows, and integrated ERP systems.
                </p>
                <p>
                  Today, Goalcraft represents the synthesis of these two worlds. We are one of the few consulting firms that can walk a factory floor with the same confidence that we architect a cloud-based ERP solution.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 bg-secondary/10 rounded-xl transform rotate-3"></div>
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" 
                alt="Team Collaboration" 
                className="relative rounded-xl shadow-lg w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="section-padding bg-gray-50">
        <div className="container-custom">
          <h2 className="text-3xl font-serif font-bold text-primary mb-12 text-center">Executive Leadership</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {LEADERS.map((leader, i) => (
              <div key={i} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300">
                <div className="h-64 overflow-hidden">
                  <img 
                    src={leader.image} 
                    alt={leader.name} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-primary">{leader.name}</h3>
                  <p className="text-secondary font-medium text-sm mb-4">{leader.role}</p>
                  <p className="text-muted-foreground text-sm leading-relaxed">{leader.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
      <ChatWidget />
    </div>
  );
}
