import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send, Bot } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";

interface Message {
  id: string;
  text: string;
  sender: "bot" | "user";
  options?: { label: string; action: string }[];
}

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello. How can we help you improve your business today?",
      sender: "bot",
      options: [
        { label: "Operational Efficiency", action: "ops" },
        { label: "Digital Transformation", action: "digital" },
        { label: "Cost Reduction", action: "cost" },
      ],
    },
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleOptionClick = (option: { label: string; action: string }) => {
    // Add user response
    const userMsg: Message = {
      id: Date.now().toString(),
      text: option.label,
      sender: "user",
    };
    setMessages((prev) => [...prev, userMsg]);

    // Simulate bot thinking
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: "Excellent choice. Our experts specialize in that area. Would you like to schedule a consultation to discuss your specific needs?",
        sender: "bot",
        options: [
          { label: "Yes, take me to contact form", action: "contact" },
        ],
      };
      setMessages((prev) => [...prev, botResponse]);
    }, 800);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="mb-4 w-80 md:w-96 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden"
          >
            {/* Header */}
            <div className="bg-primary p-4 flex justify-between items-center text-white">
              <div className="flex items-center gap-2">
                <div className="bg-white/10 p-1.5 rounded-full">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-sm">Goalcraft Assistant</h4>
                  <p className="text-xs text-blue-200">Online</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Area */}
            <div className="h-80 overflow-y-auto p-4 bg-gray-50 flex flex-col gap-3">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm ${
                      msg.sender === "user"
                        ? "bg-primary text-white rounded-tr-none"
                        : "bg-white border border-gray-200 text-gray-800 rounded-tl-none shadow-sm"
                    }`}
                  >
                    <p>{msg.text}</p>
                    {msg.options && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {msg.options.map((opt) => (
                          msg.options![0].action === 'contact' ? (
                             <Link key={opt.label} href="/contact">
                                <button className="text-xs bg-secondary/10 text-secondary border border-secondary/20 px-3 py-1.5 rounded-full hover:bg-secondary hover:text-white transition-colors font-medium">
                                  {opt.label}
                                </button>
                             </Link>
                          ) : (
                            <button
                              key={opt.label}
                              onClick={() => handleOptionClick(opt)}
                              className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-200 px-3 py-1.5 rounded-full transition-colors font-medium"
                            >
                              {opt.label}
                            </button>
                          )
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Placeholder */}
            <div className="p-3 border-t bg-white">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Type a message..."
                  disabled
                  className="w-full bg-gray-100 border-0 rounded-full px-4 py-2 text-sm focus:ring-0 cursor-not-allowed opacity-60"
                />
                <div className="absolute right-2 top-1.5 text-gray-400">
                  <Send className="w-4 h-4" />
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-secondary text-white rounded-full shadow-lg hover:shadow-xl hover:bg-secondary/90 transition-all flex items-center justify-center"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>
    </div>
  );
}
