import { Link, useLocation } from "wouter";
import { Menu, X, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

const links = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About Us" },
  { href: "/services", label: "Services" },
  { href: "/solutions", label: "Solutions" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed w-full z-50 transition-all duration-300",
        scrolled ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-gray-100 py-3" : "bg-transparent py-5"
      )}
    >
      <div className="container-custom flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group cursor-pointer">
          <div className="w-8 h-8 bg-primary rounded-sm flex items-center justify-center text-white font-serif font-bold text-xl group-hover:bg-secondary transition-colors">
            G
          </div>
          <span className={cn(
            "font-serif text-2xl font-bold tracking-tight",
            scrolled ? "text-primary" : "text-primary" // Always dark for legibility unless on dark hero
          )}>
            Goalcraft
          </span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <div
                className={cn(
                  "text-sm font-medium transition-colors hover:text-secondary cursor-pointer relative py-1",
                  location === link.href ? "text-primary font-semibold" : "text-gray-600",
                  "after:content-[''] after:absolute after:left-0 after:bottom-0 after:w-0 after:h-0.5 after:bg-secondary after:transition-all hover:after:w-full",
                  location === link.href && "after:w-full"
                )}
              >
                {link.label}
              </div>
            </Link>
          ))}
          <Link href="/contact">
            <div className="btn-primary cursor-pointer">
              Consultation
            </div>
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-primary"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-white border-t border-gray-100 shadow-lg py-4 px-4 flex flex-col space-y-4">
          {links.map((link) => (
            <Link key={link.href} href={link.href}>
              <div 
                className={cn(
                  "block text-lg font-medium py-2 border-b border-gray-50",
                  location === link.href ? "text-secondary" : "text-gray-600"
                )}
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </div>
            </Link>
          ))}
          <Link href="/contact">
            <div className="btn-primary w-full text-center mt-2" onClick={() => setIsOpen(false)}>
              Get a Consultation
            </div>
          </Link>
        </div>
      )}
    </nav>
  );
}
