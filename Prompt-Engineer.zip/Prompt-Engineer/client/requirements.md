## Packages
framer-motion | Smooth animations for the executive feel
lucide-react | Professional iconography
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  serif: ["Playfair Display", "serif"],
}
